select * from country
select * from city

select a.*, b.Name, b.District from country a inner join city b on a.Code = b.CountryCode
where a.Code = 'IND'

DELIMITER $$

CREATE PROCEDURE get_CountriesData(IN Code varchar(100))
begin
select a.*, b.Name, b.District from country a inner join city b on a.Code = b.CountryCode
where a.Code = Code;
end $$

DELIMITER ;

call get_CountriesData('CAN')


-------------------------------------------------

DELIMITER $$

CREATE PROCEDURE get_CountriesData(IN Code varchar(100), out NoOfCities int)
begin
select count(*) into NoOfCities from country a inner join city b on a.Code = b.CountryCode
where a.Code = Code;
end $$

DELIMITER ;

drop procedure get_CountriesData

call get_CountriesData('IND', @NoOfCitiesReturned);
select @NoOfCitiesReturned


