select * from country
select * from city

select a.*, b.Name, b.District from country a inner join city b on a.Code = b.CountryCode
where a.Code = 'IND'

DELIMITER $$

CREATE PROCEDURE sp_getCountryData()
begin
select a.*, b.Name, b.District from country a inner join city b on a.Code = b.CountryCode
where a.Code = 'IND';
end $$

DELIMITER ;

call sp_getCountryData

drop procedure sp_getCountryData