create table demo(Id int, FirstName varchar(100), LastName varchar(100));
insert into demo (Id, FirstName, LastName)
values (1,'Aqil', 'Ahmed'), (2,'Abhishek', 'Sinha');
select * from demo;